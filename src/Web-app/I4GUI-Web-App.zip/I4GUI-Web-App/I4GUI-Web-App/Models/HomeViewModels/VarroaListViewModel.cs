﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace I4GUIWebApp.Models.HomeViewModels
{
    public class VarroaListViewModel
    {
        public List<(string, int)> Varroa { get; set; }
    }
}
